function [ tda ] = initializejavaTDA(  )
%initializejavaTDA Initializes the TDA java object and returns it
%   Detailed explanation goes here

%clear classes;

import tda/api.*;

tda=Tda();

end

